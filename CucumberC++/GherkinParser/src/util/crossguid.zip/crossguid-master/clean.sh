rm -f *.o
rm -f *.a
rm -f *.so
rm -f testmain
rm -f *.dll
rm -f *.DLL
