#include "test.h"
#include <iostream>

int main(int argc, char *argv[])
{
  return test(GuidGenerator(), std::cout);
}
